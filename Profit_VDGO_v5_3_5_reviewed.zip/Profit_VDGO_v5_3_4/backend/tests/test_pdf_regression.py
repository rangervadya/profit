"""Fast regression checks for the most visible v5 PDF issues.

Run from project root with:
    python -m unittest discover -s backend/tests -v
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
import zipfile
from io import BytesIO

import fitz
from PIL import Image

BACKEND = Path(__file__).resolve().parents[1]
ROOT = BACKEND.parent
sys.path.insert(0, str(BACKEND))
from app import OUTPUT, TEMPLATE, build_pdf, normalize_form_dates, PAGE, append_extra_photo_pages, _ordered_uploaded_photos  # noqa: E402
from pdf_to_docx import pdf_to_docx  # noqa: E402
from pdf_to_docx_editable import pdf_to_docx_editable  # noqa: E402


class PdfRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.output = OUTPUT / "generated.pdf"
        cls.form = {
            "report_number": "QA-2026-001",
            "report_date": "14.10.2026",
            "report_year": "2026",
            "min_thickness": "2,7",
            "max_thickness": "3,5",
            "address": "Республика Татарстан, г. Казань, ул. Юлиуса Фучика, д. 105",
            "executor_legal_name": "Общество с ограниченной ответственностью «Профит»",
            "executor": "ООО «Профит»",
            "executor_phone": "+7 900 111-22-33",
            "customer_address": "420000, Республика Татарстан, г. Казань, ул. Тестовая, д. 15",
            "general_director": "В.А. Палагин",
            "customer": "ООО «Демо заказчик»",
            "customer_director": "И.И. Иванов",
            "next_diagnostic": "марта 2029 года",
            "remaining_life_years": "3 года",
            "resource_working_pressure": "1,25",
            "resource_calculated_by": "И.И. Иванов",
            "test_result": "Проверка герметичности не проводилась по причине отсутствия доступа к отдельным помещениям по акту.",
            "conclusion_text": "Запорная арматура проверена. По результатам осмотра замечаний не выявлено.",
            "defect_1_enabled": "1",
            "defect_1_location": "Подъезд № 1, участок газопровода по акту обследования.",
            "defect_1_text": "Не обеспечена заделка зазора в проходе через стену.",
            "defect_1_recommendation": "Выполнить заделку по утверждённой технологии.",
            "uk_device_model": "А1211Mini",
            "uk_device_serial": "1234567",
            "uk_calibration_date": "14.10.2026",
            "uk_joint_number": "15",
            "uk_material_description": "Сталь Ø42, толщина 3,1 мм",
            "uk_sensitivity": "1,0",
            "uk_defect_description": "Дефектов не обнаружено",
            "uk_result": "Годен",
            "uk_accessibility_percent": "100",
            "gas_status": "not_detected",
            "leak_status": "not_detected",
            # Small source-table values verify that empty/sparse cells still use readable typography.
            "uzt_shared_1_segment": "Участок 1",
            "uzt_shared_1_diameter": "32",
            "uzt_shared_1_thickness": "3,2",
            "uzt_flat_1_apartment": "1",
            "uzt_flat_1_du25": "3,2",
            "uzt_flat_1_du20": "2,8",
            "uzt_flat_1_du15": "2,4",
            "resource_section_1": "№ 1",
            "resource_kz_1": "1,1",
            "resource_thickness_1": "3,2",
            "resource_base_velocity_1": "0,01",
            "resource_k1_1": "1,0",
            "resource_k2_1": "1,0",
            "resource_factor_1": "1,0",
            "resource_velocity_1": "0,01",
            "resource_years_1": "3",
        }
        build_pdf(cls.form, {})

    @classmethod
    def tearDownClass(cls):
        cls.output.unlink(missing_ok=True)
        work = OUTPUT / "_work.pdf"
        work.unlink(missing_ok=True)

    def test_document_has_49_pages(self):
        with fitz.open(self.output) as doc:
            self.assertEqual(len(doc), 49)

    def test_cover_replacement_text_is_searchable(self):
        with fitz.open(self.output) as doc:
            text = doc[0].get_text()
            self.assertIn("QA-2026-001", text)
            self.assertIn("Республика Татарстан", text)
            self.assertIn("Юлиуса Фучика", text)
            self.assertNotIn("\ufffd", text)

    def test_generic_replacements_inherit_original_body_font_size(self):
        with fitz.open(self.output) as doc:
            page = doc[4]
            phone = next(span for block in page.get_text("dict")["blocks"] if "lines" in block
                         for line in block["lines"] for span in line["spans"]
                         if "+7 900 111-22-33" in span["text"])
            self.assertGreaterEqual(phone["size"], 10.5)
            self.assertLessEqual(phone["size"], 12.1)
            self.assertNotIn("+7 843 202-30-29", page.get_text())

    def test_appendix_5_instrument_metadata_is_not_tiny(self):
        with fitz.open(self.output) as doc:
            spans = [span for block in doc[29].get_text("dict")["blocks"] if "lines" in block
                     for line in block["lines"] for span in line["spans"]]
            model = next(span for span in spans if "А1211Mini" in span["text"])
            serial = next(span for span in spans if "1234567" in span["text"])
            self.assertGreaterEqual(model["size"], 9.3)
            self.assertGreaterEqual(serial["size"], 9.3)

    def test_appendix_2_diagrams_are_preserved(self):
        with fitz.open(self.output) as doc:
            for index, entrance in ((15, "подъезд 1"), (16, "подъезд 2")):
                text = doc[index].get_text()
                self.assertIn("неразрушающего контроля", text)
                self.assertIn("Юлиуса Фучика", text)
                self.assertIn(entrance, text)
                self.assertGreaterEqual(len(doc[index].get_images(full=True)), 1)

    def test_cover_text_is_native_pdf_text_not_an_image(self):
        with fitz.open(self.output) as doc:
            cover = doc[0]
            spans = [span for block in cover.get_text("dict")["blocks"] if "lines" in block
                     for line in block["lines"] for span in line["spans"]]
            title = next(span for span in spans if "Заключение № QA-2026-001" in span["text"])
            self.assertAlmostEqual(title["size"], 20.04, delta=0.2)
            self.assertIn("Carlito Bold", [font[3] for font in cover.get_fonts(full=True)])
            # The generated title must be a native, selectable text object, not a page PNG.
            self.assertEqual(len(cover.get_images(full=True)), 0)
            self.assertTrue(cover.search_for("QA-2026-001"))

    def test_resource_summary_keeps_original_12pt_size(self):
        with fitz.open(self.output) as doc:
            spans = [span for block in doc[8].get_text("dict")["blocks"] if "lines" in block
                     for line in block["lines"] for span in line["spans"]]
            value = next(span for span in spans if "составляет 3 года" in span["text"])
            self.assertAlmostEqual(value["size"], 12.0, delta=0.2)

    def test_russian_date_picker_values_are_normalized_for_the_pdf(self):
        form = {
            "report_date": "2026-10-14",
            "work_group_order_date": "2026-10-09",
            "uzt_calibration_date": "2025-04-03",
            "uk_calibration_date_nd": "1",
            "next_diagnostic": "2028-03-14",
        }
        normalize_form_dates(form)
        self.assertEqual(form["report_date"], "14.10.2026")
        self.assertEqual(form["work_group_order_date"], "09.10.2026")
        self.assertEqual(form["uzt_calibration_date"], "03.04.2025")
        self.assertEqual(form["uk_calibration_date"], "н.д.")
        self.assertEqual(form["next_diagnostic"], "14 марта 2028 года")

    def test_dynamic_photo_button_can_add_a_row_and_upload_cap_matches_ui(self):
        self.assertIn('onclick="addPhotoRow(true)"', PAGE)
        self.assertIn('function addPhotoRow(force=false)', PAGE)
        self.assertIn('function ensureEmptyPhotoRow()', PAGE)
        self.assertIn('512 МБ', PAGE)
        source=(BACKEND / 'app.py').read_text(encoding='utf-8')
        self.assertIn('if n>512*1024*1024:', source)
        nginx=(ROOT / 'nginx' / 'default.conf').read_text(encoding='utf-8')
        self.assertIn('client_max_body_size 512m;', nginx)

    def test_dates_accept_keyboard_digits_and_format_as_russian(self):
        self.assertIn('function maskRussianDate(input)', PAGE)
        self.assertIn('inputmode="numeric"', PAGE)
        self.assertIn('placeholder="ДД.ММ.ГГГГ"', PAGE)
        self.assertIn('function openDatePicker(name)', PAGE)
        self.assertIn('name="report_date"', PAGE)
        self.assertIn('name="next_diagnostic"', PAGE)
        self.assertIn('name="work_group_order_date"', PAGE)

    def test_all_russian_date_fields_use_keyboard_mask_and_calendar_validation(self):
        fields = ('report_date', 'work_group_order_date', 'next_diagnostic', 'uzt_calibration_date', 'uk_calibration_date')
        for field in fields:
            self.assertIn(f'id="{field}"', PAGE)
            self.assertIn(f"openDatePicker('{field}')", PAGE)
            self.assertIn('maskRussianDate(this)', PAGE)
        self.assertIn('function isValidRussianDate(value)', PAGE)
        self.assertIn('function dateDigitsToText(raw)', PAGE)
        self.assertNotIn('oninput="maskRussianDate(this)" oninput=', PAGE)

    def test_test_result_uses_readable_body_font_size(self):
        with fitz.open(self.output) as doc:
            spans = [span for block in doc[8].get_text('dict')['blocks'] if 'lines' in block
                     for line in block['lines'] for span in line['spans']]
            result = next(span for span in spans if 'Проверка герметичности не проводилась' in span['text'])
            self.assertGreaterEqual(result['size'], 9.0)

    def test_blank_photo_slots_are_white_not_black_placeholders(self):
        with fitz.open(self.output) as doc:
            page = doc[17]
            pix = page.get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
            image = Image.open(BytesIO(pix.tobytes('png'))).convert('RGB')
            pixel = image.getpixel((275, 255))
            self.assertGreaterEqual(min(pixel), 245, f'Blank photo slot should be white, got {pixel}')

    def test_word_export_contains_editable_text_and_separate_images(self):
        word_path = OUTPUT / '_editable_word_regression.docx'
        try:
            count = pdf_to_docx(self.output, word_path, dpi=96)
            self.assertEqual(count, 49)
            with zipfile.ZipFile(word_path) as zf:
                xml = zf.read('word/document.xml').decode('utf-8')
                media = [name for name in zf.namelist() if name.startswith('word/media/')]
            # Editable text boxes are native Word content; not a single page-sized screenshot per page.
            self.assertGreater(xml.count('w:txbxContent'), 500)
            self.assertIn('QA-2026-001', xml)
            self.assertIn('Юлиуса Фучика', xml)
            self.assertIn('Место установки', xml)
            self.assertGreater(len(media), 0)
        finally:
            word_path.unlink(missing_ok=True)

    def test_inserted_conclusion_keeps_body_font_size(self):
        with fitz.open(self.output) as doc:
            spans = [sp for block in doc[8].get_text('dict')['blocks'] if 'lines' in block
                     for line in block['lines'] for sp in line['spans']]
            conclusion = next(sp for sp in spans if 'Вывод: Запорная арматура проверена' in sp['text'])
            self.assertGreaterEqual(conclusion['size'], 10.4)
            self.assertLessEqual(conclusion['size'], 12.1)

    def test_defect_values_keep_readable_source_size(self):
        with fitz.open(self.output) as doc:
            spans = [sp for block in doc[9].get_text('dict')['blocks'] if 'lines' in block
                     for line in block['lines'] for sp in line['spans']]
            location = next(sp for sp in spans if 'Подъезд № 1, участок газопровода' in sp['text'])
            self.assertGreaterEqual(location['size'], 8.0)


    def test_uzt_apartment_values_match_table_typography(self):
        with fitz.open(self.output) as doc:
            page = doc[28]
            spans = [span for block in page.get_text("dict")["blocks"] if "lines" in block
                     for line in block["lines"] for span in line["spans"]]
            for value in ("3,2", "2,8", "2,4"):
                candidates = [span for span in spans if span["text"].strip() == value
                              and 115 <= span["bbox"][1] <= 430]
                self.assertTrue(candidates, f"Expected apartment UZT value {value} was not inserted")
                self.assertTrue(all(span["size"] >= 9.0 for span in candidates),
                                f"Apartment UZT value {value} has too small a font: {[s['size'] for s in candidates]}")

    def test_uzt_shared_values_match_table_typography(self):
        with fitz.open(self.output) as doc:
            page = doc[27]
            spans = [span for block in page.get_text("dict")["blocks"] if "lines" in block
                     for line in block["lines"] for span in line["spans"]]
            for value in ("Участок 1", "32", "3,2"):
                candidates = [span for span in spans if span["text"].strip() == value
                              and 390 <= span["bbox"][1] <= 430]
                self.assertTrue(candidates, f"Expected common UZT value {value} was not inserted")
                self.assertTrue(all(span["size"] >= 9.0 for span in candidates),
                                f"Common UZT value {value} has too small a font: {[s['size'] for s in candidates]}")

    def test_min_max_wall_thickness_values_are_written_to_page_7_as_12pt_text(self):
        with fitz.open(self.output) as doc:
            page = doc[6]
            spans = [sp for block in page.get_text("dict")["blocks"] if "lines" in block
                     for line in block["lines"] for sp in line["spans"]]
            min_value = next(sp for sp in spans if sp["text"].strip() == "2,7" and 605 < sp["bbox"][1] < 625)
            max_value = next(sp for sp in spans if sp["text"].strip() == "3,5" and 620 < sp["bbox"][1] < 640)
            self.assertAlmostEqual(min_value["size"], 12.0, delta=0.2)
            self.assertAlmostEqual(max_value["size"], 12.0, delta=0.2)
            self.assertNotIn("2,4", [sp["text"].strip() for sp in spans if 605 < sp["bbox"][1] < 625])

    def test_section_6_1_grid_lines_restore_original_merged_parent_row(self):
        with fitz.open(self.output) as doc:
            page = doc[9]
            lines=[]
            for drawing in page.get_drawings():
                for item in drawing.get("items", []):
                    if item[0] == "l":
                        a,b=item[1],item[2]
                        if abs(a.y-b.y)<0.05:
                            lines.append((round(a.x,2),round(a.y,2),round(b.x,2),round(b.y,2)))
            # The divider after the parent label is broken across the merged location cell.
            self.assertTrue(any(abs(y-135.98)<0.5 and x0<36 and 85<x1<88 for x0,y,x1,_ in lines),
                            "Left segment of the parent row separator is missing")
            self.assertTrue(any(abs(y-135.98)<0.5 and 304<x0<306 and x1>517 for x0,y,x1,_ in lines),
                            "Right segment of the parent row separator is missing")
            self.assertFalse(any(abs(y-135.98)<0.5 and x0<87 and x1>304 for x0,y,x1,_ in lines),
                             "The parent separator must not cross the merged location cell")
            self.assertTrue(any(abs(y-183.86)<0.5 and x0<36 and x1>517 for x0,y,x1,_ in lines),
                            "The full horizontal separator after row 1.1 must remain visible")

    def test_photo_list_is_dynamic_and_extra_images_get_appendix_pages(self):
        self.assertIn('function addPhotoRow(force=false)', PAGE)
        self.assertIn('function photoSelected(i,input)', PAGE)
        self.assertIn('id="photo-grid"', PAGE)
        from PIL import Image as PILImage
        test_image=OUTPUT/'_extra_photo_test.png'
        try:
            PILImage.new('RGB',(220,220),(120,140,160)).save(test_image)
            ordered=_ordered_uploaded_photos({'photo_23': str(test_image), 'photo_2': str(test_image), 'material_page_31':str(test_image)})
            self.assertEqual(ordered, [str(test_image), str(test_image)])
            with fitz.open(TEMPLATE) as doc:
                temps=append_extra_photo_pages(doc,[str(test_image)], {'report_number':'QA-2026','address':'Тестовый адрес'})
                try:
                    self.assertEqual(len(doc),50)
                    self.assertEqual(len(doc[-1].get_images(full=True)),1)
                    self.assertIn('Фотоматериалы (продолжение', doc[-1].get_text())
                finally:
                    for tmp in temps: Path(tmp).unlink(missing_ok=True)
        finally:
            test_image.unlink(missing_ok=True)

    def test_resource_cells_use_readable_font_fallback(self):
        with fitz.open(self.output) as doc:
            page = doc[37]
            spans = [span for block in page.get_text("dict")["blocks"] if "lines" in block
                     for line in block["lines"] for span in line["spans"]]
            for value in ("№ 1", "1,1", "3,2", "0,01"):
                candidates = [span for span in spans if span["text"].strip() == value]
                self.assertTrue(candidates, f"Expected Appendix 11 value {value} was not inserted")
                self.assertTrue(all(span["size"] >= 8.8 for span in candidates),
                                f"Appendix 11 value {value} has too small a font: {[s['size'] for s in candidates]}")

    def test_native_editable_word_uses_real_paragraphs_tables_and_separate_images(self):
        word_path = OUTPUT / '_native_word_regression.docx'
        try:
            count = pdf_to_docx_editable(self.output, word_path)
            self.assertEqual(count, 49)
            from docx import Document
            word = Document(word_path)
            self.assertGreater(len(word.paragraphs), 300)
            self.assertGreater(len(word.tables), 10)
            self.assertIn('QA-2026-001', '\n'.join(p.text for p in word.paragraphs))
            word_text = '\n'.join(p.text for p in word.paragraphs) + '\n' + '\n'.join(cell.text for table in word.tables for row in table.rows for cell in row.cells)
            self.assertIn('2,7', word_text, 'Minimum wall thickness from the form must be editable text in DOCX')
            self.assertIn('3,5', word_text, 'Maximum wall thickness from the form must be editable text in DOCX')
            self.assertGreater(len(word.inline_shapes), 0)
            self.assertLess(len(word.inline_shapes), 49)
        finally:
            word_path.unlink(missing_ok=True)


class DockerBuildContractTests(unittest.TestCase):
    def test_editable_word_exporter_is_copied_into_backend_image(self):
        dockerfile = (BACKEND / "Dockerfile").read_text(encoding="utf-8")
        self.assertIn("pdf_to_docx_editable.py", dockerfile,
                      "The backend imports pdf_to_docx_editable, so Dockerfile must copy it into /app")

    def test_runtime_uses_supported_pymupdf_import(self):
        for rel in ("app.py", "pdf_to_docx.py", "pdf_to_docx_editable.py"):
            source = (BACKEND / rel).read_text(encoding="utf-8")
            self.assertIn("import pymupdf as fitz", source, f"Expected current PyMuPDF import in {rel}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
