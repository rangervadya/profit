#!/bin/zsh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export VDGO_FORCE_LOCAL=1
exec "$ROOT/start_mac.command"
