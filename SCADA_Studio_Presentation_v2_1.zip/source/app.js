'use strict';

const svg = document.getElementById('schematic');
const pipeLayer = document.getElementById('pipeLayer');
const nodeLayer = document.getElementById('nodeLayer');
const drawingLayer = document.getElementById('drawingLayer');
const viewport = document.getElementById('diagramViewport');

let nodes = [];
let pipes = [];
let historyRows = [];
let events = [];
let selected = null;
let activeTool = 'select';
let nextNodeNo = 1;
let nextPipeNo = 1;
let nextPointNumber = 35;
let dragNode = null;
let pipeDraw = null;
let toastTimer = null;
const metadata = { name: 'Внутридомовое газовое оборудование', address: 'Объект А-01 · учебная схема' };

const toolHints = {
  select: 'Режим: выбор и перемещение элементов.',
  pipe: 'Проведите мышью от начала до конца трубопровода.',
  point: 'Щёлкните по месту установки контрольного участка.',
  sensor: 'Щёлкните по месту установки измерительного прибора.',
  valve: 'Щёлкните по месту установки клапана.',
  label: 'Щёлкните по схеме, чтобы добавить текстовую подпись.'
};

const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
const escapeXml = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&apos;' }[ch]));
const pad = n => String(n).padStart(2, '0');
const timestamp = () => new Date().toLocaleString('ru-RU', { year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit' });
const nodeById = id => nodes.find(n => n.id === id);
const pipeById = id => pipes.find(p => p.id === id);
const displayValue = n => n.value === '' || n.value === null || n.value === undefined ? '—' : String(n.value);

function toast(message) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
}

function addEvent(title, detail, warn = false) {
  events.unshift({ title, detail, time: timestamp(), warn });
  events = events.slice(0, 60);
  renderEvents();
}

function recordHistory(node, sourceOverride) {
  if (!node || node.kind === 'label') return;
  node.updated = timestamp();
  historyRows.unshift({
    time: node.updated, tag: node.tag || '', name: node.name || '', value: node.value ?? '', unit: node.unit || '',
    status: node.status || 'Не задано', source: sourceOverride || node.source || 'Ручной ввод'
  });
  if (historyRows.length > 10000) historyRows.length = 10000;
  renderHistory();
}

function makeNode(kind, x, y, overrides = {}) {
  const id = `N${nextNodeNo++}`;
  const number = kind === 'point' ? String(nextPointNumber++) : '';
  const def = {
    point: { name:`Контрольный участок ${number}`, type:'УЗТ', tag:`KD_${pad(Number(number) || nextNodeNo)}`, unit:'мм', value:'', status:'Не задано', source:'Ручной ввод', note:'' },
    sensor: { name:'Измерительный прибор', type:'Давление', tag:`SENSOR_${pad(nextNodeNo)}`, unit:'бар', value:'', status:'Не задано', source:'Ручной ввод', note:'' },
    valve: { name:'Запорный клапан', type:'Клапан', tag:`VALVE_${pad(nextNodeNo)}`, unit:'состояние', value:'Закрыт', status:'Не задано', source:'Ручной ввод', note:'' },
    label: { name:'Текстовая подпись', type:'', tag:'', unit:'', value:'', status:'Не задано', source:'', note:'' }
  }[kind] || {};
  const node = { id, kind, number, x, y, labelSide:'right', ...def, ...overrides };
  nodes.push(node);
  return node;
}

function makePipe(x1, y1, x2, y2, overrides = {}) {
  const id = `L${nextPipeNo++}`;
  const pipe = { id, x1, y1, x2, y2, name:`Трубопровод ${id}`, tag:`PIPE_${id}`, diameter:'DN25', length:'', note:'', ...overrides };
  if (!pipe.length) pipe.length = Math.round(Math.hypot(x2 - x1, y2 - y1));
  pipes.push(pipe);
  return pipe;
}

function seedProject() {
  nodes = []; pipes = []; historyRows = []; events = []; nextNodeNo = 1; nextPipeNo = 1; nextPointNumber = 35;
  metadata.name = 'Внутридомовое газовое оборудование';
  metadata.address = 'Объект А-01 · учебная схема';

  // Верхняя сеть трубопроводов — редактор может свободно изменять её.
  const baseLines = [
    [70,190,170,190,'DN25'], [170,190,260,190,'DN25'], [260,190,260,125,'DN25'],
    [260,125,360,125,'DN25'], [360,125,420,175,'DN25'], [420,175,520,175,'DN25'],
    [520,175,595,115,'DN25'], [595,115,720,115,'DN25'], [720,115,785,165,'DN25'],
    [785,165,875,165,'DN25'], [875,165,945,105,'DN25'], [945,105,1110,105,'DN25'],
    [520,175,520,280,'DN25'], [520,280,640,280,'DN25'], [640,280,700,230,'DN25'],
    [700,230,825,230,'DN25'], [825,230,900,300,'DN25'], [900,300,1090,300,'DN25'],
    [875,165,875,230,'DN25'], [875,230,825,230,'DN25'], [640,280,640,350,'DN25'],
    [640,350,750,350,'DN25'], [750,350,800,325,'DN25'], [800,325,900,300,'DN25'],
    [150,460,150,755,'DN25'], [370,460,370,755,'DN25'], [590,460,590,755,'DN25'], [810,460,810,755,'DN25']
  ];
  baseLines.forEach(([x1,y1,x2,y2,diameter], idx) => makePipe(x1,y1,x2,y2,{name:`Участок трубопровода ${idx+1}`, tag:`PIPE_${pad(idx+1)}`, diameter}));

  const columns = [
    { title:'СТ-1', x:150, count:9, start:1 },
    { title:'СТ-2', x:370, count:9, start:10 },
    { title:'СТ-3', x:590, count:8, start:19 },
    { title:'СТ-4', x:810, count:8, start:27 }
  ];
  columns.forEach((col, colIndex) => {
    for (let j = 0; j < col.count; j++) {
      const n = col.start + j;
      const value = (3.2 + ((n * 7) % 13) * 0.17).toFixed(2);
      makeNode('point', col.x, 475 + j * 32, {
        number:String(n), name:`Контрольный участок ${n}`, type:'УЗТ', tag:`KD_${pad(n)}`,
        unit:'мм', value, status:'Демо', source:'Условные данные', note:`Стояк ${colIndex + 1}`, labelSide: colIndex % 2 === 0 ? 'right' : 'left'
      });
    }
  });
  // Четыре прибора и клапан на верхней технологической части схемы.
  makeNode('sensor', 600, 115, { name:'Датчик давления P-01', type:'Давление', tag:'PRESSURE_01', unit:'бар', value:'0.42', status:'Демо', source:'Условные данные', labelSide:'right' });
  makeNode('sensor', 770, 165, { name:'Расходомер F-01', type:'Расход', tag:'FLOW_01', unit:'м³/ч', value:'128.4', status:'Демо', source:'Условные данные', labelSide:'right' });
  makeNode('sensor', 945, 105, { name:'Датчик температуры T-01', type:'Температура', tag:'TEMP_01', unit:'°C', value:'21.6', status:'Демо', source:'Условные данные', labelSide:'left' });
  makeNode('sensor', 900, 300, { name:'Датчик давления P-02', type:'Давление', tag:'PRESSURE_02', unit:'бар', value:'0.39', status:'Демо', source:'Условные данные', labelSide:'left' });
  makeNode('valve', 520, 280, { name:'Запорный клапан V-01', type:'Клапан', tag:'VALVE_01', unit:'состояние', value:'Открыт', status:'Демо', source:'Условные данные', labelSide:'left' });

  document.getElementById('objectName').value = metadata.name;
  document.getElementById('objectAddress').value = metadata.address;
  nodes.filter(n => n.kind !== 'label').forEach(n => recordHistory(n, n.source));
  addEvent('Демонстрационная схема загружена', '34 контрольных участка, измерительные приборы и трубопроводы', true);
  addEvent('Источник данных', 'Используются условные значения — связь с оборудованием не настроена', true);
  selected = null;
  activeTool = 'select';
  setTool('select');
  renderBase();
  renderAll();
}

function renderBase() {
  const colHeaders = [
    '<text x="150" y="437" class="scheme-column-title" text-anchor="middle">СТ-1 · СТОЯК</text>',
    '<text x="370" y="437" class="scheme-column-title" text-anchor="middle">СТ-2 · СТОЯК</text>',
    '<text x="590" y="437" class="scheme-column-title" text-anchor="middle">СТ-3 · СТОЯК</text>',
    '<text x="810" y="437" class="scheme-column-title" text-anchor="middle">СТ-4 · СТОЯК</text>'
  ].join('');
  document.getElementById('diagramBase').innerHTML = `
    <text x="42" y="30" class="svg-heading">СХЕМА КОНТРОЛЯ ВНУТРИДОМОВОГО ГАЗОВОГО ОБОРУДОВАНИЯ</text>
    <text x="42" y="49" class="svg-subheading">Редактируемый учебный пример · объект и адрес задаются в левой панели</text>
    <line x1="42" y1="64" x2="1155" y2="64" stroke="#e0e6ed" stroke-width="1"/>
    <text x="45" y="88" class="scheme-label">Газовый ввод / технологическая линия</text>
    <text x="44" y="177" class="scheme-label">Ввод газа</text><path d="M 48 190 L 65 190" class="base-line"/>
    <text x="998" y="85" class="scheme-label">Выход / дальнейшая линия</text>
    <text x="930" y="365" class="scheme-label">Приборы и арматура</text>
    <line x1="42" y1="406" x2="1155" y2="406" stroke="#e2e8ef" stroke-dasharray="5 5"/>
    <text x="42" y="393" class="scheme-label">КОНТРОЛЬНЫЕ УЧАСТКИ / РАЗВЁРТКА СТОЯКОВ</text>
    ${colHeaders}
    <text x="42" y="795" class="scheme-label">Номера точек, теги и показания редактируются. Все точки доступны в реестре и экспорте Excel.</text>
  `;
}

function setTool(tool) {
  activeTool = tool;
  document.querySelectorAll('.tool-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tool === tool));
  document.getElementById('toolHint').textContent = toolHints[tool] || toolHints.select;
  viewport.classList.remove('tool-pipe','tool-point','tool-sensor','tool-valve','tool-label');
  if (tool !== 'select') viewport.classList.add(`tool-${tool}`);
}

document.querySelectorAll('.tool-btn').forEach(btn => btn.addEventListener('click', () => setTool(btn.dataset.tool)));

document.getElementById('gridBtn').addEventListener('click', e => {
  viewport.classList.toggle('grid-on');
  e.currentTarget.classList.toggle('active', viewport.classList.contains('grid-on'));
});
document.getElementById('clearSelectionBtn').addEventListener('click', () => selectElement(null));
document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => switchView(btn.dataset.view)));

function switchView(view) {
  document.querySelectorAll('.tab').forEach(btn => btn.classList.toggle('active', btn.dataset.view === view));
  document.getElementById('diagramView').classList.toggle('hidden', view !== 'diagram');
  document.getElementById('registryView').classList.toggle('hidden', view !== 'registry');
  document.getElementById('historyView').classList.toggle('hidden', view !== 'history');
  if (view === 'diagram') renderDiagram();
}

function switchScreen(screen) {
  const isOverview = screen === 'overview';
  document.getElementById('overviewScreen').classList.toggle('hidden', !isOverview);
  document.getElementById('builderScreen').classList.toggle('hidden', isOverview);
  document.querySelectorAll('.app-nav-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.screen === screen));
  if (isOverview) renderOverview();
  else { renderDiagram(); renderRegistry(); renderHistory(); }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.querySelectorAll('.app-nav-btn').forEach(btn => btn.addEventListener('click', () => switchScreen(btn.dataset.screen)));
document.querySelectorAll('[data-open-constructor]').forEach(btn => btn.addEventListener('click', () => switchScreen('builder')));
document.querySelectorAll('[data-open-registry]').forEach(btn => btn.addEventListener('click', () => { switchScreen('builder'); switchView('registry'); }));
document.querySelectorAll('[data-open-history]').forEach(btn => btn.addEventListener('click', () => { switchScreen('builder'); switchView('history'); }));

function renderOverview() {
  const safe = value => escapeHtml(value ?? '');
  const dataNodes = nodes.filter(n => n.kind !== 'label');
  const pointNodes = nodes.filter(n => n.kind === 'point');
  const withValue = dataNodes.filter(n => n.value !== '' && n.value !== null && n.value !== undefined).length;
  const attention = dataNodes.filter(n => ['Предупреждение','Авария','Нет связи'].includes(n.status)).length;
  const noConnection = dataNodes.filter(n => n.status === 'Нет связи').length;
  const tagged = dataNodes.filter(n => String(n.tag || '').trim()).length;
  document.getElementById('overviewObjectName').textContent = metadata.name || 'Газовое оборудование';
  document.getElementById('overviewObjectAddress').textContent = metadata.address || 'Обзор технологической схемы и контрольных точек';
  document.getElementById('overviewPointCount').textContent = pointNodes.length;
  document.getElementById('overviewWithValue').textContent = withValue;
  document.getElementById('overviewPipeCount').textContent = pipes.length;
  document.getElementById('overviewAlerts').textContent = attention;
  document.getElementById('overviewAlertCaption').textContent = attention ? 'Требуют проверки' : 'Нет открытых предупреждений';
  document.getElementById('overviewSystemStatus').textContent = attention ? 'ВНИМАНИЕ' : 'ДЕМО';
  document.getElementById('overviewSystemStatus').classList.toggle('attention', attention > 0);

  const signalDefinitions = [
    { tag:'PRESSURE_01', name:'Давление · P-01', code:'P', tone:'blue' },
    { tag:'FLOW_01', name:'Расход · F-01', code:'F', tone:'teal' },
    { tag:'TEMP_01', name:'Температура · T-01', code:'T', tone:'purple' },
    { tag:'PRESSURE_02', name:'Давление · P-02', code:'P', tone:'blue' }
  ];
  const signalList = document.getElementById('overviewSignalList');
  signalList.innerHTML = signalDefinitions.map(def => {
    const n = nodes.find(item => item.tag === def.tag && item.kind !== 'label');
    const value = n ? displayValue(n) : '—';
    const unit = n ? n.unit : '';
    const status = n ? (n.status || 'Не задано') : 'Не задано';
    const cls = statusClass(status) || 'idle';
    return `<div class="signal-row"><div class="signal-type ${def.tone}">${def.code}</div><div class="signal-description"><strong>${safe(n ? n.name : def.name)}</strong><span>${safe(def.tag)} <i>·</i> ${safe(n ? (n.source || 'источник не указан') : 'тег пока не добавлен')}</span></div><div class="signal-measure"><strong>${safe(value)}</strong><span>${safe(unit)}</span></div><span class="signal-status ${cls}">${safe(status)}</span></div>`;
  }).join('');

  const rows = [
    { name:'Теги источников', note:'Назначено контрольным точкам и приборам', value:`${tagged} / ${dataNodes.length}`, tone:'teal' },
    { name:'Заполненные значения', note:'Значения присутствуют в проекте', value:`${withValue} / ${dataNodes.length}`, tone:'blue' },
    { name:'Нет связи', note:'Элементам не назначен активный источник', value:String(noConnection), tone:noConnection ? 'amber' : 'teal' },
    { name:'Трубопроводная сеть', note:'Сегменты доступны в конструкторе', value:String(pipes.length), tone:'purple' }
  ];
  document.getElementById('overviewStatusRows').innerHTML = rows.map(row => `<div class="status-row"><span class="status-row-mark ${row.tone}"></span><div class="status-row-text"><strong>${safe(row.name)}</strong><span>${safe(row.note)}</span></div><b>${safe(row.value)}</b></div>`).join('');

  const eventRoot = document.getElementById('overviewEventList');
  const recentEvents = events.slice(0, 4);
  eventRoot.innerHTML = recentEvents.length ? recentEvents.map(evt => `<div class="overview-event${evt.warn ? ' event-warning' : ''}"><span class="event-timeline-dot"></span><div class="overview-event-body"><strong>${safe(evt.title)}</strong><span>${safe(evt.detail)}</span></div><time>${safe(evt.time)}</time></div>`).join('') : '<div class="overview-event-empty">Событий пока нет. Изменения проекта появятся в этом журнале.</div>';
}

function renderAll() {
  renderDiagram(); renderRegistry(); renderHistory(); renderEvents(); updateSummary();
}

function renderDiagram() {
  pipeLayer.innerHTML = pipes.map(pipe => {
    const isSelected = selected && selected.type === 'pipe' && selected.id === pipe.id;
    const mx = (pipe.x1 + pipe.x2) / 2, my = (pipe.y1 + pipe.y2) / 2;
    const label = pipe.diameter ? `<text x="${mx}" y="${my - 7}" class="pipe-caption" text-anchor="middle">${escapeXml(pipe.diameter)}</text>` : '';
    return `<g data-pipewrap="${escapeHtml(pipe.id)}"><line data-pipeid="${escapeHtml(pipe.id)}" class="pipe-segment${isSelected ? ' selected' : ''}" x1="${pipe.x1}" y1="${pipe.y1}" x2="${pipe.x2}" y2="${pipe.y2}"/>${label}</g>`;
  }).join('');

  nodeLayer.innerHTML = nodes.map(node => {
    const isSelected = selected && selected.type === 'node' && selected.id === node.id;
    if (node.kind === 'label') {
      return `<g class="node-group${isSelected ? ' selected' : ''}" data-nodeid="${escapeHtml(node.id)}" transform="translate(${node.x} ${node.y})"><text class="label-node${isSelected ? ' selected-label' : ''}" x="0" y="0">${escapeXml(node.name)}</text></g>`;
    }
    if (node.kind === 'sensor') {
      const dx = node.labelSide === 'left' ? -116 : 15;
      const v = displayValue(node);
      const glyph = (node.type || 'P').toUpperCase().startsWith('ТЕМП') ? 'T' : (node.type || '').toUpperCase().startsWith('РАСХ') ? 'F' : 'P';
      const badgeClass = statusClass(node.status);
      return `<g class="node-group${isSelected ? ' selected' : ''}" data-nodeid="${escapeHtml(node.id)}" transform="translate(${node.x} ${node.y})">
        <circle class="sensor-disc" r="11"/><text class="sensor-glyph" x="0" y="0">${glyph}</text><circle class="status-ring ${badgeClass}" cx="8" cy="-8" r="4"/>
        <rect class="node-label-bg" x="${dx}" y="-17" width="101" height="35" rx="4"/><text class="node-label-num" x="${dx + 6}" y="-4">${escapeXml(shorten(node.name, 18))}</text><text class="node-label-type" x="${dx + 6}" y="8">${escapeXml(v)} ${escapeXml(node.unit)}</text><text class="node-tag" x="${dx + 6}" y="27">${escapeXml(node.tag)}</text>
      </g>`;
    }
    if (node.kind === 'valve') {
      const dx = node.labelSide === 'left' ? -90 : 16;
      return `<g class="node-group${isSelected ? ' selected' : ''}" data-nodeid="${escapeHtml(node.id)}" transform="translate(${node.x} ${node.y})">
        <path class="valve-shape" d="M -10 -8 L 0 0 L -10 8 Z M 10 -8 L 0 0 L 10 8 Z"/><circle class="status-ring ${statusClass(node.status)}" cx="10" cy="-10" r="4"/>
        <rect class="node-label-bg" x="${dx}" y="-13" width="82" height="28" rx="4"/><text class="node-label-num" x="${dx + 5}" y="-1">${escapeXml(shorten(node.name, 16))}</text><text class="node-label-type" x="${dx + 5}" y="10">${escapeXml(displayValue(node))}</text>
      </g>`;
    }
    const dx = node.labelSide === 'left' ? -68 : 14;
    return `<g class="node-group${isSelected ? ' selected' : ''}" data-nodeid="${escapeHtml(node.id)}" transform="translate(${node.x} ${node.y})">
      <circle class="point-disc" r="7.5"/><path class="point-cross" d="M -4 0 H 4 M 0 -4 V 4"/><circle class="status-ring ${statusClass(node.status)}" cx="6" cy="-6" r="3"/>
      <rect class="node-label-bg" x="${dx}" y="-13" width="59" height="26" rx="3"/><text class="node-label-num" x="${dx + 4}" y="-2">№ ${escapeXml(node.number || '?')}</text><text class="node-label-type" x="${dx + 4}" y="8">${escapeXml(node.type || 'КТ')}</text>
    </g>`;
  }).join('');
  document.getElementById('diagramEmpty').classList.toggle('hidden', nodes.length + pipes.length > 0);
  attachDiagramEvents();
  updateSummary();
}

function shorten(text, max) { text = String(text || ''); return text.length > max ? text.slice(0, max - 1) + '…' : text; }
function statusClass(status) {
  if (status === 'Авария') return 'alarm';
  if (status === 'Предупреждение') return 'warn';
  if (status === 'Норма') return 'ok';
  return status === 'Демо' ? 'demo' : '';
}
function localPoint(event) {
  const p = svg.createSVGPoint(); p.x = event.clientX; p.y = event.clientY;
  const matrix = svg.getScreenCTM();
  if (!matrix) return { x: 600, y: 400 };
  const q = p.matrixTransform(matrix.inverse());
  return { x: Math.max(0, Math.min(1195, q.x)), y: Math.max(0, Math.min(815, q.y)) };
}

function attachDiagramEvents() {
  nodeLayer.querySelectorAll('[data-nodeid]').forEach(el => {
    el.addEventListener('pointerdown', event => {
      if (activeTool !== 'select') return;
      event.stopPropagation();
      const id = el.dataset.nodeid;
      const node = nodeById(id); if (!node) return;
      selectElement({ type:'node', id });
      dragNode = { id, start: localPoint(event), x: node.x, y: node.y, moved:false };
      try { svg.setPointerCapture(event.pointerId); } catch (_) {}
    });
    el.addEventListener('click', event => {
      if (activeTool === 'select') { event.stopPropagation(); selectElement({ type:'node', id:el.dataset.nodeid }); }
    });
  });
  pipeLayer.querySelectorAll('[data-pipeid]').forEach(el => {
    el.addEventListener('pointerdown', event => {
      if (activeTool !== 'select') return;
      event.stopPropagation();
      selectElement({ type:'pipe', id:el.dataset.pipeid });
    });
    el.addEventListener('click', event => {
      if (activeTool === 'select') { event.stopPropagation(); selectElement({ type:'pipe', id:el.dataset.pipeid }); }
    });
  });
}

svg.addEventListener('pointerdown', event => {
  if (activeTool !== 'pipe') return;
  const p = localPoint(event);
  pipeDraw = { x1:p.x, y1:p.y, x2:p.x, y2:p.y, pointerId:event.pointerId };
  drawingLayer.innerHTML = `<line class="drawing-preview" x1="${p.x}" y1="${p.y}" x2="${p.x}" y2="${p.y}"/>`;
  try { svg.setPointerCapture(event.pointerId); } catch (_) {}
  event.preventDefault();
});
svg.addEventListener('pointermove', event => {
  if (!pipeDraw) return;
  const p = localPoint(event); pipeDraw.x2 = p.x; pipeDraw.y2 = p.y;
  drawingLayer.innerHTML = `<line class="drawing-preview" x1="${pipeDraw.x1}" y1="${pipeDraw.y1}" x2="${p.x}" y2="${p.y}"/>`;
});
window.addEventListener('pointerup', event => {
  if (pipeDraw) {
    const line = pipeDraw; pipeDraw = null; drawingLayer.innerHTML = '';
    if (Math.hypot(line.x2 - line.x1, line.y2 - line.y1) > 12) {
      const pipe = makePipe(line.x1, line.y1, line.x2, line.y2, { name:`Трубопровод L${nextPipeNo}`, tag:`PIPE_L${nextPipeNo}`, diameter:'DN25' });
      addEvent('Добавлен трубопровод', `${pipe.name} (${pipe.diameter})`);
      selectElement({ type:'pipe', id:pipe.id });
      renderAll();
    }
  }
  if (dragNode) {
    if (dragNode.moved) renderAll();
    dragNode = null;
  }
});
window.addEventListener('pointermove', event => {
  if (!dragNode) return;
  const current = localPoint(event); const node = nodeById(dragNode.id); if (!node) return;
  node.x = Math.max(8, Math.min(1185, dragNode.x + current.x - dragNode.start.x));
  node.y = Math.max(78, Math.min(800, dragNode.y + current.y - dragNode.start.y));
  if (Math.hypot(current.x - dragNode.start.x, current.y - dragNode.start.y) > 2) dragNode.moved = true;
  const el = nodeLayer.querySelector(`[data-nodeid="${CSS.escape(node.id)}"]`);
  if (el) el.setAttribute('transform', `translate(${node.x} ${node.y})`);
});

svg.addEventListener('click', event => {
  const p = localPoint(event);
  if (activeTool === 'point' || activeTool === 'sensor' || activeTool === 'valve' || activeTool === 'label') {
    let node;
    if (activeTool === 'label') node = makeNode('label', p.x, p.y, { name:'Новая подпись' });
    else node = makeNode(activeTool, p.x, p.y);
    selectElement({ type:'node', id:node.id });
    addEvent('Добавлен элемент схемы', node.name);
    renderAll();
    return;
  }
  if (activeTool === 'select' && (event.target === svg || event.target.id === 'svgBackground' || event.target.closest('#diagramBase'))) {
    selectElement(null);
  }
});

function selectElement(target) {
  selected = target;
  renderProperties();
  renderDiagram();
}

function renderProperties() {
  const empty = document.getElementById('emptyProperties');
  const form = document.getElementById('propertiesForm');
  const node = selected && selected.type === 'node' ? nodeById(selected.id) : null;
  const pipe = selected && selected.type === 'pipe' ? pipeById(selected.id) : null;
  const item = node || pipe;
  empty.classList.toggle('hidden', !!item);
  form.classList.toggle('hidden', !item);
  if (!item) return;
  document.getElementById('propName').value = item.name || '';
  document.getElementById('propNumber').value = node ? (node.number || '') : '';
  document.getElementById('propType').value = node ? (node.type || '') : (pipe.diameter || 'DN25');
  document.getElementById('propTag').value = item.tag || '';
  document.getElementById('propValue').value = node ? (item.value ?? '') : (pipe.length ?? '');
  document.getElementById('propUnit').value = node ? (item.unit || '') : 'условные ед.';
  document.getElementById('propStatus').value = node ? (item.status || 'Не задано') : 'Не задано';
  document.getElementById('propSource').value = node ? (item.source || '') : 'Геометрия схемы';
  document.getElementById('propNote').value = item.note || '';
  const numberLabel = document.querySelector('#numberWrap .field-label:first-child');
  const typeLabel = document.querySelector('#numberWrap .field-label:last-child');
  const numberInput = document.getElementById('propNumber');
  if (pipe) {
    numberLabel.childNodes[0].nodeValue = '№ сегмента ';
    typeLabel.childNodes[0].nodeValue = 'DN / сечение ';
    numberInput.value = pipe.id;
    document.getElementById('propValue').previousElementSibling;
  } else {
    numberLabel.childNodes[0].nodeValue = '№ участка ';
    typeLabel.childNodes[0].nodeValue = 'Тип контроля ';
  }
  document.getElementById('deleteElementBtn').textContent = pipe ? 'Удалить сегмент' : 'Удалить элемент';
}

document.getElementById('propertiesForm').addEventListener('submit', event => {
  event.preventDefault();
  if (!selected) return;
  const name = document.getElementById('propName').value.trim();
  const tag = document.getElementById('propTag').value.trim();
  const type = document.getElementById('propType').value.trim();
  const value = document.getElementById('propValue').value.trim();
  const unit = document.getElementById('propUnit').value.trim();
  const note = document.getElementById('propNote').value.trim();
  if (selected.type === 'node') {
    const node = nodeById(selected.id); if (!node) return;
    const oldValue = node.value;
    node.name = name || node.name;
    if (node.kind === 'point') node.number = document.getElementById('propNumber').value.trim() || node.number;
    node.type = type; node.tag = tag || node.tag; node.value = value; node.unit = unit;
    node.status = document.getElementById('propStatus').value;
    node.source = document.getElementById('propSource').value.trim() || 'Ручной ввод'; node.note = note;
    if (oldValue !== node.value || node.status !== 'Демо') recordHistory(node, node.source);
    addEvent('Изменены свойства элемента', `${node.name} · тег ${node.tag}`);
  } else {
    const pipe = pipeById(selected.id); if (!pipe) return;
    pipe.name = name || pipe.name; pipe.tag = tag || pipe.tag; pipe.diameter = type || pipe.diameter;
    pipe.length = value; pipe.note = note;
    addEvent('Изменён трубопровод', `${pipe.name} · ${pipe.diameter}`);
  }
  renderAll(); renderProperties(); toast('Изменения применены');
});

document.getElementById('deleteElementBtn').addEventListener('click', () => {
  if (!selected) return;
  if (selected.type === 'node') {
    const node = nodeById(selected.id);
    nodes = nodes.filter(n => n.id !== selected.id);
    addEvent('Элемент удалён', node ? node.name : selected.id, true);
  } else {
    const pipe = pipeById(selected.id);
    pipes = pipes.filter(p => p.id !== selected.id);
    addEvent('Сегмент удалён', pipe ? pipe.name : selected.id, true);
  }
  selected = null; renderAll(); renderProperties(); toast('Элемент удалён из схемы');
});

document.getElementById('autoArrangeBtn').addEventListener('click', () => {
  const pointNodes = nodes.filter(n => n.kind === 'point');
  const columns = [150,370,590,810];
  pointNodes.forEach((node, i) => {
    const colIndex = i % 4;
    const rowIndex = Math.floor(i / 4);
    node.x = columns[colIndex]; node.y = 475 + rowIndex * 32;
    node.labelSide = colIndex % 2 === 0 ? 'right' : 'left';
  });
  addEvent('Схема выровнена', 'Позиции контрольных точек упорядочены по четырём колоннам');
  renderAll(); toast('Контрольные точки выровнены');
});

document.getElementById('objectName').addEventListener('change', event => {
  metadata.name = event.target.value.trim() || 'Объект без названия';
  document.getElementById('pageTitle').textContent = metadata.name;
  renderOverview();
});
document.getElementById('objectAddress').addEventListener('change', event => { metadata.address = event.target.value.trim(); renderOverview(); });

function renderRegistry() {
  const query = (document.getElementById('registrySearch').value || '').toLowerCase().trim();
  const rows = nodes.filter(n => n.kind !== 'label').filter(n => [n.name,n.tag,n.number,n.type,n.status].some(v => String(v ?? '').toLowerCase().includes(query)));
  document.getElementById('registryBody').innerHTML = rows.length ? rows.map(node => `<tr data-row-node="${escapeHtml(node.id)}" tabindex="0">
    <td>${escapeHtml(node.number || '—')}</td><td title="${escapeHtml(node.name)}">${escapeHtml(node.name)}</td><td class="tag-cell">${escapeHtml(node.tag)}</td>
    <td>${escapeHtml(node.type || node.kind)}</td><td class="value-cell">${escapeHtml(displayValue(node))}</td><td>${escapeHtml(node.unit || '—')}</td>
    <td><span class="status-badge ${statusClass(node.status)}">${escapeHtml(node.status || 'Не задано')}</span></td><td>${escapeHtml(node.source || '—')}</td><td>${escapeHtml(node.updated || '—')}</td>
    <td><button class="row-open" type="button">Открыть</button></td></tr>`).join('') : '<tr><td colspan="10" class="empty-row">По запросу ничего не найдено.</td></tr>';
  document.getElementById('registrySummary').textContent = `${rows.length} из ${nodes.filter(n => n.kind !== 'label').length} записей`;
  document.getElementById('registryBadge').textContent = nodes.filter(n => n.kind !== 'label').length;
  document.getElementById('pointCount').textContent = nodes.filter(n => n.kind === 'point').length;
  document.getElementById('pipeCount').textContent = pipes.length;
  document.getElementById('registryBody').querySelectorAll('tr[data-row-node]').forEach(row => {
    const openRow = () => {
      const id = row.dataset.rowNode;
      switchView('diagram'); selectElement({ type:'node', id });
      const node = nodeById(id); if (node) toast(`Выбрано: ${node.name}`);
    };
    row.addEventListener('click', openRow);
    row.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openRow(); } });
  });
}

document.getElementById('registrySearch').addEventListener('input', renderRegistry);
document.getElementById('addPointBtn').addEventListener('click', () => {
  const pointNodes = nodes.filter(n => n.kind === 'point');
  const row = Math.floor(pointNodes.length / 4), col = pointNodes.length % 4;
  const x = [150,370,590,810][col], y = Math.min(780, 475 + row * 32);
  const node = makeNode('point', x, y, { labelSide: col % 2 === 0 ? 'right' : 'left' });
  nextPointNumber = Math.max(nextPointNumber, Number(node.number || 0) + 1);
  recordHistory(node, node.source); addEvent('Добавлена контрольная точка', node.name);
  renderAll(); switchView('diagram'); selectElement({ type:'node', id:node.id }); toast('Добавлена новая точка контроля');
});

function renderHistory() {
  const query = (document.getElementById('historySearch').value || '').toLowerCase().trim();
  const rows = historyRows.filter(row => [row.time,row.tag,row.name,row.status,row.source].some(v => String(v ?? '').toLowerCase().includes(query)));
  document.getElementById('historyBody').innerHTML = rows.length ? rows.slice(0,1500).map(row => `<tr><td>${escapeHtml(row.time)}</td><td class="tag-cell">${escapeHtml(row.tag)}</td><td>${escapeHtml(row.name)}</td><td class="value-cell">${escapeHtml(row.value === '' ? '—' : row.value)}</td><td>${escapeHtml(row.unit || '—')}</td><td><span class="status-badge ${statusClass(row.status)}">${escapeHtml(row.status || 'Не задано')}</span></td><td>${escapeHtml(row.source || '—')}</td></tr>`).join('') : '<tr><td colspan="7" class="empty-row">История пока пуста.</td></tr>';
  document.getElementById('historySummary').textContent = `${rows.length} записей в архиве${rows.length > 1500 ? ' · показаны последние 1500' : ''}`;
}
document.getElementById('historySearch').addEventListener('input', renderHistory);
document.getElementById('clearHistoryBtn').addEventListener('click', () => {
  if (!confirm('Очистить весь архив измерений? Это действие нельзя отменить.')) return;
  historyRows = []; renderHistory(); addEvent('Архив измерений очищен', 'Удалены все записи истории', true); toast('История очищена');
});

function renderEvents() {
  document.getElementById('eventLog').innerHTML = events.slice(0,5).map(evt => `<div class="event-entry${evt.warn ? ' warn' : ''}"><div class="event-icon">${evt.warn ? '!' : '·'}</div><div class="event-text"><b>${escapeHtml(evt.title)}</b><small>${escapeHtml(evt.detail)}</small></div><span class="event-time">${escapeHtml(evt.time)}</span></div>`).join('');
  const overviewEventRoot = document.getElementById('overviewEventList');
  if (overviewEventRoot) renderOverview();
}
document.getElementById('addEventBtn').addEventListener('click', () => {
  const label = prompt('Текст записи журнала:');
  if (!label || !label.trim()) return;
  addEvent('Запись оператора', label.trim()); toast('Запись добавлена в журнал');
});

function updateSummary() {
  const controlPoints = nodes.filter(n => n.kind === 'point').length;
  const dataNodes = nodes.filter(n => n.kind !== 'label');
  const withValue = dataNodes.filter(n => n.value !== '' && n.value !== null && n.value !== undefined).length;
  const alerts = dataNodes.filter(n => ['Предупреждение','Авария','Нет связи'].includes(n.status)).length;
  document.getElementById('summaryPoints').textContent = controlPoints;
  document.getElementById('summaryWithValue').textContent = withValue;
  document.getElementById('summaryAlerts').textContent = alerts;
  document.getElementById('pointCount').textContent = controlPoints;
  document.getElementById('pipeCount').textContent = pipes.length;
  document.getElementById('pageTitle').textContent = metadata.name || 'Схема газового оборудования';
  document.getElementById('pageSubtitle').textContent = metadata.address || 'Редактор технической схемы с контрольными точками';
  renderOverview();
}

// Project save/open (JSON).
document.getElementById('saveProjectBtn').addEventListener('click', () => {
  metadata.name = document.getElementById('objectName').value.trim() || metadata.name;
  metadata.address = document.getElementById('objectAddress').value.trim();
  const project = { format:'SCADA-Studio-Project', version:2, exportedAt:new Date().toISOString(), metadata, nodes, pipes, historyRows, events };
  downloadBlob(new Blob([JSON.stringify(project, null, 2)], { type:'application/json;charset=utf-8' }), 'scada-project.json');
  addEvent('Проект сохранён', 'Схема, теги, значения и история сохранены в JSON'); toast('Проект сохранён в файл JSON');
});
document.getElementById('openProjectBtn').addEventListener('click', () => document.getElementById('projectFile').click());
document.getElementById('projectFile').addEventListener('change', async event => {
  const file = event.target.files && event.target.files[0]; if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (!Array.isArray(data.nodes) || !Array.isArray(data.pipes)) throw new Error('В файле нет списков nodes и pipes');
    nodes = data.nodes; pipes = data.pipes; historyRows = Array.isArray(data.historyRows) ? data.historyRows : [];
    events = Array.isArray(data.events) ? data.events : [];
    Object.assign(metadata, data.metadata || {});
    nextNodeNo = Math.max(1, ...nodes.map(n => Number(String(n.id || '').replace(/\D/g,'')) + 1).filter(Number.isFinite));
    nextPipeNo = Math.max(1, ...pipes.map(p => Number(String(p.id || '').replace(/\D/g,'')) + 1).filter(Number.isFinite));
    nextPointNumber = Math.max(1, ...nodes.filter(n => n.kind === 'point').map(n => Number(n.number) + 1).filter(Number.isFinite));
    document.getElementById('objectName').value = metadata.name || '';
    document.getElementById('objectAddress').value = metadata.address || '';
    selected = null; renderAll(); renderProperties(); switchView('diagram'); addEvent('Проект открыт', file.name); toast(`Загружен проект: ${file.name}`);
  } catch (error) { toast(`Не удалось открыть проект: ${error.message}`); }
  event.target.value = '';
});

// CSV data import: updates matching tags and adds unmatched tags as new control points.
document.getElementById('importCsvBtn').addEventListener('click', () => document.getElementById('csvFile').click());
document.getElementById('csvFile').addEventListener('change', async event => {
  const file = event.target.files && event.target.files[0]; if (!file) return;
  try {
    const text = (await file.text()).replace(/^\uFEFF/, '');
    const delimiter = detectDelimiter(text);
    const rows = parseDelimited(text, delimiter).filter(row => row.some(cell => String(cell).trim() !== ''));
    if (rows.length < 2) throw new Error('В CSV нет строк данных');
    const headers = rows[0].map(s => String(s).trim().toLowerCase());
    const findCol = aliases => headers.findIndex(h => aliases.some(a => h === a || h.includes(a)));
    const tagCol = findCol(['тег','тэг','tag','id источника','source id','код точки']);
    const nameCol = findCol(['название','точка','объект','name','описание']);
    const valueCol = findCol(['значение','показание','value','измерение','толщина','расход']);
    const unitCol = findCol(['единица','ед.','unit','ед изм']);
    const statusCol = findCol(['статус','status','состояние']);
    const timeCol = findCol(['время','дата','timestamp','time']);
    let updated = 0, added = 0;
    for (const row of rows.slice(1)) {
      const tag = String(row[tagCol >= 0 ? tagCol : 0] || '').trim();
      if (!tag) continue;
      const val = String(row[valueCol >= 0 ? valueCol : Math.min(1,row.length-1)] ?? '').trim();
      const name = nameCol >= 0 ? String(row[nameCol] || '').trim() : '';
      let node = nodes.find(n => n.kind !== 'label' && String(n.tag || '').toLowerCase() === tag.toLowerCase());
      if (!node) {
        const pointNodes = nodes.filter(n => n.kind === 'point');
        const col = pointNodes.length % 4;
        const rowIndex = Math.floor(pointNodes.length / 4);
        const x = [150,370,590,810][col]; const y = Math.min(790, 475 + rowIndex * 32);
        node = makeNode('point', x, y, { name:name || `Импортированная точка ${tag}`, number:String(nextPointNumber++), tag, labelSide:col % 2 === 0 ? 'right' : 'left', source:'Импорт CSV' });
        added++;
      } else updated++;
      node.tag = tag; if (name) node.name = name; node.value = val;
      if (unitCol >= 0 && row[unitCol] !== undefined) node.unit = String(row[unitCol]).trim();
      if (statusCol >= 0 && row[statusCol]) node.status = normalizeStatus(String(row[statusCol]).trim());
      else node.status = 'Норма';
      node.source = 'Импорт CSV'; node.updated = timeCol >= 0 && row[timeCol] ? String(row[timeCol]).trim() : timestamp();
      recordHistory(node, 'Импорт CSV');
    }
    addEvent('Импортирован CSV-файл', `${file.name}: обновлено ${updated}, добавлено ${added}`);
    renderAll(); switchView('registry'); toast(`Импорт готов: обновлено ${updated}, добавлено новых точек ${added}`);
  } catch (error) { toast(`Ошибка импорта CSV: ${error.message}`); }
  event.target.value = '';
});
function normalizeStatus(s) {
  const t = s.toLowerCase();
  if (t.includes('авар') || t.includes('alarm') || t.includes('fault')) return 'Авария';
  if (t.includes('предуп') || t.includes('warn')) return 'Предупреждение';
  if (t.includes('нет связи') || t.includes('offline') || t.includes('disconnect')) return 'Нет связи';
  if (t.includes('демо') || t.includes('demo')) return 'Демо';
  if (t.includes('норма') || t.includes('ok') || t.includes('normal')) return 'Норма';
  return s || 'Норма';
}
function detectDelimiter(text) {
  const firstLine = text.split(/\r?\n/).find(line => line.trim()) || '';
  const options = [';',',','\t'];
  return options.sort((a,b) => firstLine.split(b).length - firstLine.split(a).length)[0];
}
function parseDelimited(text, delimiter) {
  const rows = []; let row = [], cell = '', quoted = false;
  for (let i=0;i<text.length;i++) {
    const ch = text[i];
    if (ch === '"' && quoted && text[i+1] === '"') { cell += '"'; i++; }
    else if (ch === '"') quoted = !quoted;
    else if (ch === delimiter && !quoted) { row.push(cell); cell = ''; }
    else if ((ch === '\n' || ch === '\r') && !quoted) {
      if (ch === '\r' && text[i+1] === '\n') i++;
      row.push(cell); rows.push(row); row = []; cell = '';
    } else cell += ch;
  }
  if (cell.length || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

// Excel workbook export (OOXML XLSX), generated locally with no external libraries.
document.getElementById('exportXlsxBtn').addEventListener('click', exportWorkbook);
document.getElementById('exportCsvBtn').addEventListener('click', exportHistoryCsv);
function N(value) { return { __numeric:true, value: value === '' || value === null || value === undefined ? '' : Number(String(value).replace(',','.')) }; }
function cellXml(ref, input) {
  if (input && input.__numeric) {
    if (!Number.isFinite(input.value)) return `<c r="${ref}"/>`;
    return `<c r="${ref}" t="n"><v>${input.value}</v></c>`;
  }
  if (input === null || input === undefined || input === '') return `<c r="${ref}"/>`;
  return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${escapeXml(input)}</t></is></c>`;
}
function excelCol(n) { let out=''; while(n>0){const rem=(n-1)%26;out=String.fromCharCode(65+rem)+out;n=Math.floor((n-1)/26);}return out; }
function sheetXml(rows) {
  const maxCols = Math.max(1, ...rows.map(r => r.length));
  const rowXml = rows.map((row, ri) => {
    const cells = row.map((v, ci) => cellXml(`${excelCol(ci+1)}${ri+1}`, v)).join('');
    return `<row r="${ri+1}">${cells}</row>`;
  }).join('');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="16"/><cols>${Array.from({length:maxCols},(_,i)=>`<col min="${i+1}" max="${i+1}" width="${[0,1,2,3].includes(i)?20:17}" customWidth="1"/>`).join('')}</cols><sheetData>${rowXml}</sheetData><autoFilter ref="A1:${excelCol(maxCols)}${Math.max(1, rows.length)}"/></worksheet>`;
}
function exportWorkbook() {
  metadata.name = document.getElementById('objectName').value.trim() || metadata.name;
  metadata.address = document.getElementById('objectAddress').value.trim();
  const datapoints = nodes.filter(n => n.kind !== 'label');
  const pointRows = [[ '№ участка', 'Название', 'Тег / ID источника', 'Тип контроля / прибора', 'Текущее значение', 'Единица измерения', 'Статус', 'Источник данных', 'Время обновления', 'Примечание', 'Координата X', 'Координата Y' ], ...datapoints.map(n => [n.number || '', n.name, n.tag, n.type || n.kind, n.value === '' ? '' : (isNumeric(n.value) ? N(n.value) : n.value), n.unit, n.status, n.source, n.updated || '', n.note || '', N(n.x), N(n.y)])];
  const history = [[ 'Время записи', 'Тег / ID источника', 'Контрольная точка', 'Значение', 'Единица измерения', 'Статус', 'Источник данных' ], ...historyRows.slice().reverse().map(h => [h.time,h.tag,h.name,h.value === '' ? '' : (isNumeric(h.value) ? N(h.value) : h.value),h.unit,h.status,h.source])];
  const pipeline = [[ 'ID сегмента', 'Название', 'Тег', 'Сечение / DN', 'Длина (условные ед.)', 'X начала', 'Y начала', 'X конца', 'Y конца', 'Примечание' ], ...pipes.map(p => [p.id,p.name,p.tag,p.diameter,p.length === '' ? '' : (isNumeric(p.length) ? N(p.length) : p.length),N(p.x1),N(p.y1),N(p.x2),N(p.y2),p.note || ''])];
  const eventRows = [[ 'Время', 'Событие', 'Описание', 'Важность' ], ...events.slice().reverse().map(e => [e.time,e.title,e.detail,e.warn ? 'Требует внимания' : 'Информация'])];
  const objectRows = [[ 'Параметр', 'Значение' ], ['Название объекта',metadata.name],['Адрес / описание',metadata.address],['Дата экспорта',timestamp()],['Количество контрольных точек',String(nodes.filter(n=>n.kind==='point').length)],['Количество приборов и клапанов',String(nodes.filter(n=>['sensor','valve'].includes(n.kind)).length)],['Количество сегментов трубопровода',String(pipes.length)],['Режим','ДЕМО — показания условные'],['Подключение оборудования','Не настроено в браузерном прототипе']];
  const sheetNames = ['Точки и приборы','История измерений','Трубопроводы','Журнал событий','Объект'];
  const rowsList = [pointRows,history,pipeline,eventRows,objectRows];
  const files = {};
  files['[Content_Types].xml'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheetNames.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`;
  files['_rels/.rels'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  files['xl/workbook.xml'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>${sheetNames.map((name,i)=>`<sheet name="${escapeXml(name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets></workbook>`;
  files['xl/_rels/workbook.xml.rels'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheetNames.map((_,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}<Relationship Id="rId${sheetNames.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
  files['xl/styles.xml'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  rowsList.forEach((rows,i) => { files[`xl/worksheets/sheet${i+1}.xml`] = sheetXml(rows); });
  const blob = new Blob([buildZip(files)], { type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  downloadBlob(blob, 'scada-data-export.xlsx');
  addEvent('Экспорт в Excel', `Выгружено ${datapoints.length} точек, ${historyRows.length} записей истории и ${pipes.length} сегментов`);
  toast('Excel-книга создана: 5 листов с данными и историей');
}
function isNumeric(value) { return value !== null && value !== '' && Number.isFinite(Number(String(value).replace(',','.'))); }

function exportHistoryCsv() {
  const rows = [['Время','Тег / ID источника','Контрольная точка','Значение','Единица измерения','Статус','Источник данных'], ...historyRows.slice().reverse().map(h => [h.time,h.tag,h.name,h.value,h.unit,h.status,h.source])];
  const csv = '\uFEFF' + rows.map(row => row.map(v => `"${String(v ?? '').replace(/"/g,'""')}"`).join(';')).join('\r\n');
  downloadBlob(new Blob([csv], { type:'text/csv;charset=utf-8;' }), 'scada-history.csv');
  addEvent('Экспорт истории в CSV', `${historyRows.length} записей`); toast('История выгружена в CSV для Excel');
}

function buildZip(files) {
  const encoder = new TextEncoder();
  const localParts = [], centralParts = [];
  let localOffset = 0;
  const crcTable = buildCrcTable();
  for (const [path, content] of Object.entries(files)) {
    const name = encoder.encode(path);
    const data = encoder.encode(content);
    const crc = crc32(data, crcTable);
    const local = new Uint8Array(30 + name.length + data.length);
    const lv = new DataView(local.buffer);
    lv.setUint32(0,0x04034b50,true); lv.setUint16(4,20,true); lv.setUint16(6,0x0800,true); lv.setUint16(8,0,true);
    lv.setUint16(10,0,true); lv.setUint16(12,0x0021,true); lv.setUint32(14,crc,true); lv.setUint32(18,data.length,true); lv.setUint32(22,data.length,true);
    lv.setUint16(26,name.length,true); lv.setUint16(28,0,true); local.set(name,30); local.set(data,30+name.length);
    localParts.push(local);
    const central = new Uint8Array(46 + name.length); const cv = new DataView(central.buffer);
    cv.setUint32(0,0x02014b50,true); cv.setUint16(4,20,true); cv.setUint16(6,20,true); cv.setUint16(8,0x0800,true); cv.setUint16(10,0,true);
    cv.setUint16(12,0,true); cv.setUint16(14,0x0021,true); cv.setUint32(16,crc,true); cv.setUint32(20,data.length,true); cv.setUint32(24,data.length,true);
    cv.setUint16(28,name.length,true); cv.setUint16(30,0,true); cv.setUint16(32,0,true); cv.setUint16(34,0,true); cv.setUint16(36,0,true); cv.setUint32(38,0,true); cv.setUint32(42,localOffset,true); central.set(name,46);
    centralParts.push(central); localOffset += local.length;
  }
  const centralSize = centralParts.reduce((sum,p)=>sum+p.length,0);
  const end = new Uint8Array(22); const ev = new DataView(end.buffer); ev.setUint32(0,0x06054b50,true); ev.setUint16(4,0,true); ev.setUint16(6,0,true); ev.setUint16(8,centralParts.length,true); ev.setUint16(10,centralParts.length,true); ev.setUint32(12,centralSize,true); ev.setUint32(16,localOffset,true); ev.setUint16(20,0,true);
  return concatBytes([...localParts,...centralParts,end]);
}
function concatBytes(parts) {
  const total = parts.reduce((sum,p)=>sum+p.length,0); const result = new Uint8Array(total); let offset=0;
  for (const part of parts) { result.set(part,offset); offset += part.length; }
  return result;
}
function buildCrcTable() {
  const table = new Uint32Array(256);
  for (let n=0;n<256;n++) { let c=n; for(let k=0;k<8;k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1); table[n]=c>>>0; }
  return table;
}
function crc32(data, table) { let c=0xffffffff; for (let i=0;i<data.length;i++) c=table[(c ^ data[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1500);
}

// Clicking on a table/search input should re-render only its own table. Avoid fake online telemetry.
seedProject();
